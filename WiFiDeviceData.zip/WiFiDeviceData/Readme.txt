Transfer Learning Dataset In Pervasive Computing

Copyright by Vincent W. Zheng (http://www.cse.ust.hk/~vincentz).
Any question, please send email to vincentz_AT_cse.ust.hk.
October 19th, 2008.

---------------------------------------------------------------------------------------------------

[Paper]: "Transferring Multi-device Localization Models using Latent Multi-task Learning". In AAAI-08.
	 Vincent W. Zheng, Sinno J. Pan, Qiang Yang and Jeffrey J. Pan. 

---------------------------------------------------------------------------------------------------

[Data]: WiFiDeviceData.mat

---------------------------------------------------------------------------------------------------

[Data Oerview]: 

WiFiTime data is to study the WiFi signal variation over device.

(1) The data is collected at in an academic building of Hong Kong University of Science and Technology. 
    The environment is equipped with 802.11g wireless network. The area is 64m x 50m. 
    We collected data in total 107 locations, each measuring 1.5m x 1.5m. 

(2) Totally, 2 different device data are collected. For each device, we collect over 60 examples at each grid.

---------------------------------------------------------------------------------------------------

[Detailed Description]:

Load WiFiDeviceData.mat in Matlab, and we will get:

(1) 'XA' denotes the data collected at device A, with rows as examples, 
    columns as features (signal strengths from 118 access points).

(2) 'LA' denotes the corresponding grid indices (label as grid) for XA.

(3) 'YA' denotes the corresponding 2-D coordinates (label as coordinate) for XA.

(4) Similarly, we have 'XB', 'LB', 'YB' for device B data.
